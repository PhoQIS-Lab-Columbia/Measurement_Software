import subprocess
import psutil
import json
import csv
import psutil
from Instruments.EInstrument import EInstrument
class Flowmeter:
    def __init__(self, csv_files, default_csv_save_path = "C:/Users/phoqi/Documents/NQ Sensor Monitor/",program_open = False):
        """Initializes the Flowmeter class and opens the NQ Sensor Monitor software."""
        self.name = EInstrument.FLOW_METER
        with open('program_paths.json') as file:
            p = json.load(file)
        self.program_path = p[self.name.value]
        self.name = EInstrument.FLOW_METER
        pieces = self.program_path.split('/')
        self.default_csv_path = default_csv_save_path
        if self.process_exists(pieces[len(pieces)-1]):
            self.app = self.get_process_by_name(pieces[len(pieces)-1])
        else:
            self.app = subprocess.Popen([self.program_path], shell = False) # Placeholder for a path to 
        self.flowmeter_count = 1
        self.csv_paths = [""]*self.flowmeter_count
        print("The flowmeter will open a pop up window. Press start to begin monitoring. When enough time has passed, collect a csv using the NQ software. Copy the file path and load ")
    
    def process_exists(self, process_name): 
        """Check if there is any running process that contains the given name processName.
        
        :param process_name: Name of the process to check.
        :type process_name: str
        :return: True if the process is running, False otherwise.
        :rtype: bool"""
        call = 'TASKLIST', '/FI', f'imagename eq {process_name}'
        output = subprocess.check_output(call).decode()
        last_line = output.strip().split('\r\n')[-1]
        return last_line.lower().startswith(process_name.lower())
    def get_process_by_name(self,name):
        """Return the first psutil.Process object matching the process name."""
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] and proc.info['name'].lower() == name.lower():
                return proc  # This is a psutil.Process object
        return None
    def add_csv(self, flowmeter_ports, new_files):
        """Add a new csv path for a specfic flowmeter in a particular NQ port.

        :param flowmeter_port: The port number of the flowmeter (0-indexed).
        :type flowmeter_port: int
        :param new_path: The file path to the csv file.
        :type new_path: str
        """
        self.csv_paths[flowmeter_ports] = new_files
    def load_csv(self, folder_path = None):
        """Load csv data into a list of dictionaries.

        :param folder_path: The folder path where the csv files are located. If None, uses default path.
        :type folder_path: str
        :return: A list of dictionaries containing the csv data for each flowmeter.
        :rtype: list
        """
        data = []
        if folder_path is None:
            folder_path = self.default_csv_path
        for i in range(0,self.flowmeter_count):
            with open(folder_path+self.csv_paths[i], 'r') as file:
                d = csv.DictReader(file) # Returns rows as dictionaries
                data.append(d)

        return data
        
    def disconnect(self):
        """
        Ends data logging on the flowmeter and closes NQ.
        """
        
        self.app.terminate()